import os
import subprocess

def checkSudo():
    if not 'SUDO_UID' in os.environ.keys():
        print("Please run as Sudo")
        exit(1)

def system_call(command):
    p = subprocess.Popen([command], stdout=subprocess.PIPE, shell=True)
    return p.stdout.read().decode("utf-8")

def disable_unused_filesystems():
    commands = [["Ensure mounting of cramfs filesystems is disabled",
                "modprobe -n -v cramfs | grep -v mtd",
                "install /bin/true",
                 "https://workbench.cisecurity.org/sections/433194/recommendations/722183",
                ["echo 'install cramfs /bin/true' >> /etc/modprobe.d/cramfs.conf"]],

                ["Ensure mounting of cramfs filesystems is disabled",
                 "lsmod | grep cramfs",
                 "",
                 "https://workbench.cisecurity.org/sections/433194/recommendations/722183",
                 ["rmmod cramfs"]],

                ["Ensure mounting of freevxfs filesystems is disabled",
                 "modprobe -n -v freevxfs",
                 "install /bin/true",
                 "https://workbench.cisecurity.org/sections/433194/recommendations/722189",
                 ["echo 'install freevxfs /bin/true' >> /etc/modprobe.d/freevxfs.conf"]],

                ["Ensure mounting of freevxfs filesystems is disabled",
                 "lsmod | grep freevxfs",
                 "",
                 "https://workbench.cisecurity.org/sections/433194/recommendations/722183",
                 ["rmmod freevxfs"]],
                ]
    for description, command, expectedResult, fixURL, fixCommand in commands:
        print("==============",description, "==============")
        response = system_call(command)
        print("Expected:",expectedResult)
        if expectedResult not in response:
            print("Response:",response,"\nHarden: ", fixURL)
            userInput = input("Fix Automatically? (y/n): ")
            if userInput == "" or userInput.lower()[0] == "y":
                print("Fixing")
                for fix in fixCommand:
                    print(system_call(fix))
                print("\n\n")
        else:
            print("Got expected response\n\n")

if __name__ == "__main__":
    checkSudo()
    disable_unused_filesystems()